function visi() {
  const a = document.querySelector(".sec");
  const sec1 =document.querySelector("#sec1") ;
  if (sec1.style.display!="none") {
    sec1.style.display ="none";
  } else {
    sec1.style.display="block";
  }
}
